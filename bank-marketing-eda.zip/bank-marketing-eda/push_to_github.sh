#!/usr/bin/env bash
# Usage: bash push_to_github.sh <github-username>
# Pehle github.com pe "bank-marketing-eda" naam ka EMPTY repo bana lo (README/gitignore add mat karna).
set -e
USER="${1:?GitHub username do: bash push_to_github.sh <username>}"
git init
git add .
git commit -m "Add bank marketing EDA and visualization notebook"
git branch -M main
git remote add origin "https://github.com/$USER/bank-marketing-eda.git"
git push -u origin main
