# Bank Marketing Campaign – EDA & Visualization

Exploratory Data Analysis (EDA) of a bank's marketing campaign dataset using Python.
The goal is to clean the raw data and understand which customer characteristics relate to a customer subscribing to a term deposit (`response`).

## Workflow

1. **Load data** – read `bank_data.csv` with pandas
2. **Understand data** – shape, info, head/tail, feature descriptions
3. **Data cleaning**
   - Skipped junk header rows, dropped rows with missing `age`, fixed dtypes
   - Dropped the `customerid` column (identifier only)
   - Checked for duplicates
   - Split `jobedu` into separate `job` and `education` columns
   - Filled missing `month` with the mode and missing `response` with `no`
   - Renamed columns (`housing` → `housing loan`, `loan` → `personal loan`)
   - Converted `month` to datetime and extracted `month_name` and `year`
   - Fixed the mixed-unit `duration` column (seconds and minutes) into minutes
4. **Visualization**
   - **Univariate:** histogram, KDE plot, pie chart, count plots, box plots, distribution of `duration`
   - **Bivariate:** violin plot (balance by marital status), box/bar plots (salary by job), count plot with `hue` (marital status vs response), scatter plot (age vs balance), box plot (call duration vs response), stacked bar (housing loan vs response %)

## Tech Stack

Python · pandas · NumPy · Matplotlib · Seaborn · Jupyter Notebook

## Project Structure

```
bank-marketing-eda/
├── notebooks/
│   └── EDA_and_Visualization.ipynb
├── data/
│   └── bank_data.csv        # add the dataset here
├── requirements.txt
└── README.md
```

## How to Run

```bash
git clone https://github.com/<your-username>/bank-marketing-eda.git
cd bank-marketing-eda
pip install -r requirements.txt
# put bank_data.csv inside the data/ folder
jupyter notebook notebooks/EDA_and_Visualization.ipynb
```

## Author

**Sanjeet Kumar** – Post-Graduate Program in Data Science & AI (Digicrome Academy)
