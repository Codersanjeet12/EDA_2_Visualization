Yaha `bank_data.csv` file rakho (notebook isi path se read karta hai: `../data/bank_data.csv`).
